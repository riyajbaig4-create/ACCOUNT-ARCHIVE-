<?php
$url = $_SERVER["SERVER_NAME"];  
define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://puffxlivehost.cloud');
define('STYLESHEETS_URL', '//puffxlivehost.cloud' );
// Custom admin panel url segment -> https://yoursite.com/ckmr
define('ADMIN_PATH', 'ckmr');
date_default_timezone_set('Asia/Kolkata');
error_reporting(0);
return [
  'db' => [
    'name'    =>  'puffxliv_sm' ,
    'host'    =>  'localhost',
    'user'    =>  'puffxliv_sm' ,
    'pass'    =>  '5JoRHO*5FW5S' ,
    'charset' =>  'utf8mb4' 
  ]
];
?>